<?php $__env->startSection('conteudo'); ?>
	    <h2 class="titulo">Lista de Clientes</h2>

	<?php //$clientes = array(); ?>

<?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <ul class="list-group margem">
	  		<li class="list-group-item"><span class="badge client"><?php echo e($cliente->points); ?>

	  		</span><?php echo e($cliente->cpf); ?></li>
		</ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>