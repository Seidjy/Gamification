<?php $__env->startSection('conteudo'); ?>
    <h2 class="titulo">Creditar</h2>

    <form action="<?php echo e(route('deal.store')); ?>" method="POST" role="form" class="fformularios">
    	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >
        <div class="form-group form-contact">
        	<label>CPF do Participante</label>
            <input name="cpf" type="text" class="form-control" id="" placeholder="CPF Cliente" required="required">
            <label>Valor da Compra</label>
            <input name="amount" type="number" class="form-control" id="" placeholder="Compra" required="required">
        </div>
        <button type="submit" class="btn btn-primary btn-contact btn-block">Confirmar</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>