<?php $__env->startSection('conteudo'); ?>
    <h2 class="titulo">Definir Regra para cumprir</h2>

    <form action="<?php echo e(route('achieve.store')); ?>" method="POST" role="form" class="fformularios">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >
        <div class="form-group form-contact">
            <label>Nome</label>
            <input name="name" type="text" class="form-control" id="" placeholder="Nome" required="required">
            <label>Tipo de conquista</label>
            <select name="idTypeAchieve" id="input" class="form-control" required="required">
                <?php $__currentLoopData = $achieves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achieve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($achieve->id); ?>"><?php echo e($achieve->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label>Acumulação</label>
            <select id="input" type="number" name="gather" class="form-control" required="required" placeholder="Definir Limitação">
                    <option value="0">Não Acumulativo</option>
                    <option value="1">Acumulativo</option>
            </select>
            <label>Quantidade</label>
            <input name="amount" type="number" class="form-control" id="" placeholder="Quantidade" required="required">
        </div>
        <button type="submit" class="btn btn-primary btn-contact btn-block">Confirmar</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>