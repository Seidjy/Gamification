<?php $__env->startSection('conteudo'); ?>
	    <h2 class="titulo">Eventos</h2>

	<?php //$eventos = array(); ?>


	    <ul class="list-group margem">
	  		<li class="list-group-item"><span class="badge even">
	  			<i class="fa fa-check-circle eventos-list" aria-hidden="true"></i>
	  		</span>Evento </li>
		</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>