<?php $__env->startSection('conteudo'); ?>
    <h2 class="titulo">Definir Recompensa</h2>

    <form action="<?php echo e(route('awards.store')); ?>" method="POST" role="form" class="fformularios">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >
        <div class="form-group form-contact">
            <label>Nome</label>
            <input name="name" type="text" class="form-control" id="" placeholder="Nome" required="required">
            <label>Tipo de prêmio</label>
            <select name="idTypeAward" id="input" class="form-control" required="required">
                <?php $__currentLoopData = $awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($award->id); ?>"><?php echo e($award->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label>Quantidade</label>
            <input name="amount" type="number" class="form-control" id="" placeholder="Quantidade" required="required">
        </div>
        <button type="submit" class="btn btn-primary btn-contact btn-block">Confirmar</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>