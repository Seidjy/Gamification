<?php $__env->startSection('conteudo'); ?>
	    <h2 class="titulo">Conquistas</h2>

	<?php //$eventos = array(); ?>

<?php $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <ul class="list-group margem">
	  		<li class="list-group-item"><span class="badge even">
	  			<i class="fa fa-check-circle eventos-list" aria-hidden="true"></i>
	  		</span><?php echo e($goal->name); ?></li>
		</ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    <a href="<?php echo e(route('goals.create')); ?>" class="btn btn-primary btn-contact btn-block">+</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>