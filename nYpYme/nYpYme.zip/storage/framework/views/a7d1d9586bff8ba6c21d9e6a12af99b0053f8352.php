<?php $__env->startSection('conteudo'); ?>
    <h2 class="titulo">Criar Conquista</h2>

    <form action="<?php echo e(route('goals.store')); ?>" method="POST" role="form" class="fformularios">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >
        <div class="form-group form-contact">
            <label>Nome da conquista</label>
            <input name="name" type="text" class="form-control" id="" placeholder="Nome da Conquista" required="required">
            <label>Regra para conquistar</label>
            <select name="idRuleToAchieve" id="input" class="form-control" required="required">
            	<?php $__currentLoopData = $achieves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achieve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($achieve->id); ?>"><?php echo e($achieve->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label>Regras para limitar</label>
            <select name="idRuleToRestrict" id="input" class="form-control" required="required">
            	<?php $__currentLoopData = $restricts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restrict): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($restrict->id); ?>"><?php echo e($restrict->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label>Regras de premiação</label>
            <select name="idRuleToAward" id="input" class="form-control" required="required">
                <?php $__currentLoopData = $awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($award->id); ?>"><?php echo e($award->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
           
        </div>
       <button type="submit" class="btn btn-primary btn-contact btn-block">Cadastrar</button>
        </form>
         
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>