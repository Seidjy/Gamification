<?php $__env->startSection('conteudo'); ?>
    <h2 class="titulo">Definir Limitação</h2>

    <form action="<?php echo e(route('restricts.store')); ?>" method="POST" role="form" class="fformularios">
    	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >
        <div class="form-group form-contact">
        	<input type="text" class="form-control" name="name" placeholder="Nome" required="required">
        	<select id="input" name="idTypeRestrict" class="form-control" required="required" placeholder="Definir Limitação">
        		<?php $__currentLoopData = $restricts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restrict): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <option value="<?php echo e($restrict->id); ?>"><?php echo e($restrict->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input type="number" class="form-control" name="amount" placeholder="Intervalo" required="required">
        </div>
        <button type="submit" class="btn btn-primary btn-contact btn-block">Confirmar</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>