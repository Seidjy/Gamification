<?php $__env->startSection('conteudo'); ?>
	    <h2 class="titulo">Lista de Clientes</h2>

	<?php //$clientes = array(); ?>


	    <ul class="list-group margem">
	  		<li class="list-group-item"><span class="badge client">434
	  		</span>Cliente </li>
		</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>