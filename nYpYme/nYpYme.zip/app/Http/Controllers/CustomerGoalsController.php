	<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CustomerGoalsController extends Controller
{
    //
}