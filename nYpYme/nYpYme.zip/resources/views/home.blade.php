@extends('app')

@section('conteudo')
    <h1 class="titulo">NyPyme</h1>
    <div class="container sub-title">
        <h2>Nypyme é uma plataforma com soluções de gamificação.</h2>
        <p>Esta é a melhor maneira para fidelização de clientes.</p>
    </div>
@endsection